# HotelManagementSystem Home WORK
This repository was created for students of IT STEP Academy ASTANA.

All HW`s related ASP .NET Core MVC  during the study will be pushed here.

*** Rules of pushing HWs: 

1) pull this repository
2) add changes as the HW`s description
3) create a new branch, you should type your changes as feature/projectName/functionality/YourNAME   *DON`T push for the MAIN branch.
4) check for outgoing and incoming changes to sure that you don`t have merge conflicts
5) PUSH and in the GitHub web site create a new pull request. NOTE!!! when your create pull request Assign Zh-987 as REVIEWER!!! and wait to approve your pull request.
7) Then relax ;) and wait for the grade and comment.

Bussines concept of this project.
This project was created for only study purposes.
This system should have 3 roles Admin, Manager, and User.
Other business concepts will be described in the HW pdf`s.
