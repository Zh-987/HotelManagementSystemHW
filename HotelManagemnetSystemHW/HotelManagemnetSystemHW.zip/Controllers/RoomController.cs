﻿using Microsoft.AspNetCore.Mvc;

namespace HotelManagemnetSystemHW.Controllers
{
  public class RoomController : Controller
  {
    public IActionResult Index()
    {
      return View();
    }
  }
}
