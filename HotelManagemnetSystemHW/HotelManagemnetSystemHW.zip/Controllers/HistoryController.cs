﻿using Microsoft.AspNetCore.Mvc;

namespace HotelManagemnetSystemHW.Controllers
{
  public class HistoryController : Controller
  {
    public IActionResult Index()
    {
      return View();
    }
  }
}
