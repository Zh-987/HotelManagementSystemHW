﻿namespace HotelManagemnetSystemHW.Areas.User.Models
{
    public class User
    {
    }
}
