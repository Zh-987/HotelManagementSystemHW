﻿namespace HotelManagemnetSystemHW.Areas.Admin.Models
{
    public class Admin
    {
    }
}
