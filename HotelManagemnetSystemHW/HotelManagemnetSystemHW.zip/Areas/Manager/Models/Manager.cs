﻿namespace HotelManagemnetSystemHW.Areas.Manager.Models
{
    public class Manager
    {
    }
}
